class CircuitSystemSizeError(ValueError):
    """Raised when gate targets exceed system size."""

    def __init__(self, target: int, n: int) -> None:
        super().__init__(f"Qubit index {target} exceeds system size {n}")


class PauliOperatorLengthError(ValueError):
    """Raised when Pauli operator length exceeds expected size."""

    def __init__(self, length: int, n: int) -> None:
        super().__init__(f"Pauli operator length {length} exceeds expected size {n}")
