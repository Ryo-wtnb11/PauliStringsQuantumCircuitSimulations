from typing import Self

import jax
import jax.numpy as np
import stim

from paulistringsquantumcircuitsimulations.exceptions import PauliOperatorLengthError

PauliString = str

powers_of_two = 1 << np.arange(64, dtype=np.uint64)


@jax.jit
def pack_bits(bool_array: np.ndarray) -> np.ndarray:
    (ndim_sum, ndim) = bool_array.shape
    ndim_out = (ndim + 63) // 64
    res = np.zeros((ndim_sum, ndim_out), dtype=np.uint64)

    blocks = np.arange(ndim) // 64
    positions = np.arange(ndim) % 64

    bit_values = (bool_array * (1 << positions)).astype(np.uint64)

    def update_row(res_row: np.ndarray, bit_row: np.ndarray) -> np.ndarray:
        return res_row.at[blocks].set(bit_row)

    return jax.vmap(update_row, in_axes=(0, 0))(res, bit_values)


class PauliOperators:
    """A class for representing a list of Pauli operators.

    Attributes:
        bits: np.ndarray
            The bits of the Pauli operators.
        phases: np.ndarray
            The phases of the Pauli operators.
        coefficients: np.ndarray
            The coefficients of the Pauli operators.
        nq: int
            The number of qubits.

    """

    def __init__(self, bits: np.ndarray, phases: np.ndarray, coefficients: np.ndarray, nq: int) -> None:
        self.bits = bits
        self.phases = phases
        self.coefficients = coefficients
        self.nq = nq

    @classmethod
    def from_strings(
        cls,
        paulistrings: list[str],
        n_qubits: int,
        phases: list[int] | None = None,
        coefficients: list[float] | None = None,
    ) -> Self:
        """Create a PauliOperators from a list of Pauli strings and a list of phases.

        Args:
            paulistrings: list[str]
                A list of Pauli strings.
            n_qubits: int
                The number of qubits.
            phases: list[int]
                The list of phases of the Pauli operators.
            coefficients: list[float]
                The list of coefficients of the Pauli operators.

        """
        if phases is None:
            phases = [1] * len(paulistrings)
        if coefficients is None:
            coefficients = [1.0] * len(paulistrings)

        phases_ = np.array(phases, dtype=np.int64)
        coefficients_ = np.array(coefficients, dtype=np.float64)

        paulis: list[stim.PauliString] = [stim.PauliString(ps) for ps in paulistrings]
        xs, zs = zip(*[ps.to_numpy() for ps in paulis], strict=False)
        xs_ = np.array(xs, dtype=np.bool_)
        zs_ = np.array(zs, dtype=np.bool_)
        bits = np.hstack((pack_bits(xs_), pack_bits(zs_)))

        for ps in paulistrings:
            if len(ps) != n_qubits:
                raise PauliOperatorLengthError(len(ps), n_qubits)

        return cls(bits, phases_, coefficients_, n_qubits)

    def __size__(self) -> int:
        """Get the size of the bits array.

        Returns:
            The size of the bits array.

        """
        return self.bits.size()
