def main() -> int:
    """Return 0."""
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
