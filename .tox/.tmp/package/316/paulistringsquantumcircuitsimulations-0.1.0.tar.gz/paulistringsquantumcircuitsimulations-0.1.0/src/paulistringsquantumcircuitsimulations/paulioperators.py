from typing import Self

import jax
import jax.numpy as jnp
import numpy.typing as npt
import stim

from paulistringsquantumcircuitsimulations.exceptions import PauliOperatorLengthError

PauliString = str

powers_of_two = 1 << jnp.arange(64, dtype=jnp.uint64)


@jax.jit
def _update_row(
    res_row: npt.NDArray[jnp.uint64],
    bit_row: npt.NDArray[jnp.uint64],
    blocks: npt.NDArray[jnp.int64],
) -> npt.NDArray[jnp.uint64]:
    return res_row.at[blocks].add(bit_row)


@jax.jit
def pack_bits(bool_array: npt.NDArray[jnp.bool_]) -> npt.NDArray[jnp.uint64]:
    (ndim_sum, ndim) = bool_array.shape
    ndim_out = (ndim + 63) // 64
    res = jnp.zeros((ndim_sum, ndim_out), dtype=jnp.uint64)

    blocks = jnp.arange(ndim) // 64
    positions = jnp.arange(ndim) % 64

    bit_values = (bool_array * (1 << positions)).astype(jnp.uint64)

    return jax.vmap(_update_row, in_axes=(0, 0, None))(res, bit_values, blocks)


@jax.jit
def _find_index_for_one_row(lower, upper, bits, other, nq_bits):
    for i in range(nq_bits):
        if upper == lower:
            break
        bits_col = jax.lax.dynamic_slice(
            bits,
            (lower, i),
            (upper, i + 1),
        ).flatten()
        target_value = jnp.take(other, i)

        # `searchsorted` で新しい `lower` と `upper` を計算
        left_index = jnp.searchsorted(bits_col, target_value, side="left")
        right_index = jnp.searchsorted(bits_col, target_value, side="right")

        lower += left_index
        upper += right_index

    return lower


@jax.jit
def find_bit_index(bits: npt.NDArray[jnp.uint64], others: npt.NDArray[jnp.uint64]) -> npt.NDArray[jnp.int64]:
    n_others, nq_others = others.shape
    n_bits, nq_bits = bits.shape

    # `vmap` で j に対する並列処理を実施
    return jax.vmap(_find_index_for_one_row, in_axes=(None, None, None, 0, None))(
        0,
        n_bits,
        bits,
        others,
        nq_bits,
    )


class PauliOperators:
    """A class for representing a list of Pauli operators.

    Attributes:
        bits: npt.NDArray[jnp.uint64]
            The bits of the Pauli operators.
        phases: npt.NDArray[jnp.int64]
            The phases of the Pauli operators.
        coefficients: npt.NDArray[jnp.float64]
            The coefficients of the Pauli operators.
        nq: int
            The number of qubits.

    """

    def __init__(
        self,
        bits: npt.NDArray[jnp.uint64],
        phases: npt.NDArray[jnp.int64],
        coefficients: npt.NDArray[jnp.float64],
        nq: int,
    ) -> None:
        self.bits = bits
        self.phases = phases
        self.coefficients = coefficients
        self.nq = nq

    @classmethod
    def from_strings(
        cls,
        paulistrings: list[str],
        n_qubits: int,
        phases: list[int] | None = None,
        coefficients: list[float] | None = None,
    ) -> Self:
        """Create a PauliOperators from a list of Pauli strings and a list of phases.

        Args:
            paulistrings: list[str]
                A list of Pauli strings.
            n_qubits: int
                The number of qubits.
            phases: list[int]
                The list of phases of the Pauli operators.
            coefficients: list[float]
                The list of coefficients of the Pauli operators.

        """
        if phases is None:
            phases = [1] * len(paulistrings)
        if coefficients is None:
            coefficients = [1.0] * len(paulistrings)

        phases_ = jnp.array(phases, dtype=jnp.int64)
        coefficients_ = jnp.array(coefficients, dtype=jnp.float64)

        paulis: list[stim.PauliString] = [stim.PauliString(ps) for ps in paulistrings]
        xs, zs = zip(*[ps.to_numpy() for ps in paulis], strict=False)
        xs_ = jnp.array(xs, dtype=jnp.bool_)
        zs_ = jnp.array(zs, dtype=jnp.bool_)
        bits = jnp.hstack((pack_bits(xs_), pack_bits(zs_)))

        for ps in paulistrings:
            if len(ps) != n_qubits:
                raise PauliOperatorLengthError(len(ps), n_qubits)

        return cls(bits, phases_, coefficients_, n_qubits)

    def order_paulis(self) -> None:
        (n_operators, nq_orders) = self.size()
        indices = jnp.lexsort([self.bits[:, j] for j in reversed(range(nq_orders))])
        self.bits = self.bits[indices]
        self.phases = self.phases[indices]
        self.coefficients = self.coefficients[indices]

    def find_pauli_indices(self, others: Self) -> npt.NDArray[jnp.int32]:
        """Find the indices of the Others Pauli operators in the PauliOperators.

        Args:
            others: Self
                The PauliOperators to find the indices of.

        Returns:
            npt.NDArray[jnp.int32]: The indices of the Others Pauli operators in the PauliOperators.

        """
        return find_bit_index(self.bits, others.bits)

    def size(self) -> tuple[int, ...]:
        """Get the size of the bits array.

        Returns:
            The size of the bits array.

        """
        return self.bits.shape
