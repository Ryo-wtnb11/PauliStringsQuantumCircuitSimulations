import numpy as np
import stim

from paulistringsquantumcircuitsimulations.paulioperators import PauliOperators

def packbits_test(bool_array: np.ndarray) -> np.ndarray:
    ndim1, ndim2 = np.shape(bool_array)
    ndim2_out = np.ceil(ndim2 / 64).astype(np.int64)
    res = np.empty((ndim1, ndim2_out), dtype=np.uint64)
    for i in range(ndim1):
        for j in range(ndim2_out):
            tmp = bool_array[i, j * 64 : min((j + 1) * 64, ndim2)]
            res[i, j] = np.sum((1 << np.arange(64, dtype=np.uint64))[0 : tmp.size] * tmp)
    return res

def hstack_packbits(paulistrings: list[str]) -> np.ndarray:
    xs, zs = zip(*[stim.PauliString(ps).to_numpy() for ps in paulistrings], strict=False)
    xs_ = np.array(xs, dtype=np.bool_)
    zs_ = np.array(zs, dtype=np.bool_)
    return np.hstack((packbits_test(xs_), packbits_test(zs_)))

def test_paulioperator_init() -> None:
    paulistrings = ["___", "__X", "__Y", "__Z"]
    pauli_operators = PauliOperators.from_strings(paulistrings=paulistrings, n_qubits=3)

    bits = hstack_packbits(paulistrings)
    assert np.all(pauli_operators.bits == bits)

    paulistrings = ["XYZ_YZXZ_ZY__Y_Z"]
    pauli_operators = PauliOperators.from_strings(paulistrings=paulistrings, n_qubits=16)

    bits = hstack_packbits(paulistrings)
    assert np.all(pauli_operators.bits == bits)


